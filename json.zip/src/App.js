import React, { Component } from "react"
import {Switch, Route} from 'react-router-dom'
import Home from "./pages/Home"
import Bank from "./pages/Bank"
import Default from "./pages/Default"
import './App.scss'

class App extends Component {
  render() {
    return (
      <div>
        <React.Fragment > 
          <Switch>
            <Route exact path="/bank" component={Bank} />
            <Route exact path="/" component={Home} />
            <Route component={Default} />
          </Switch>
        </React.Fragment>
      </div>
    );
  }
}

export default App;
      