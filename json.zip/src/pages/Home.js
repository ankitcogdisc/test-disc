import React, { Component } from 'react'
import { 
    Row,
    Col, 
    ListGroup, 
    ListGroupItem,
    Form,
    FormGroup,
    Label,
    Input,
    Jumbotron,
    Container,
    Button
} from 'reactstrap';

import styled from 'styled-components'
import * as list from '../json/list.json';

export default class Home extends Component {
    render() {
        return (
            <Jumbotron>
                <Wrapper>  
                    <Container>
                        <Row>
                            <Col>
                                <ListGroup>
                                    {
                                        list.data.map((item,index) => {
                                            return(
                                                <ListGroupItem key={index}>maskedccoundID : {item.id} => file : {item.file}</ListGroupItem>
                                            )
                                        })
                                    }
                                    
                                </ListGroup>
                            </Col>
                            <Col>
                                <Form action="/bank">
                                    <FormGroup row>
                                        <Label for="exampleEmail" sm={2}>AccountID</Label>
                                        <Col sm={10}>
                                            <Input type="text" name="accountID" id="accountID" placeholder="with maskedccoundID" />
                                        </Col>
                                    </FormGroup>
                                    <FormGroup check row>
                                        <Col sm={{ size: 10, offset: 2 }}>
                                            <Button>Login</Button>
                                        </Col>
                                    </FormGroup>
                                </Form>
                            </Col>
                        </Row>  
                    </Container>
                </Wrapper>
            </Jumbotron>
        )
    }
}

const Wrapper = styled.div`

`;
