import React, { Component } from 'react'
import { 
    Row,
    Jumbotron,
    Container,
    Col
} from 'reactstrap';

import styled from 'styled-components'
import * as list from '../json/list.json';


export default class Bank extends Component {
    render() {
        let search = window.location.search;
        let params = new URLSearchParams(search);
        let id = params.get('accountID');
        var bankData = list.data.filter((item) => item.id === id);
       
        if(bankData.length === 0){
            return (
                <Jumbotron>
                    <Wrapper>  
                        <Container>
                            <Row>
                                Incorrect accountID!
                            </Row>  
                        </Container>
                    </Wrapper>
                </Jumbotron>
            )
        }
        else{
            const data = require(`../json/${bankData[0].file}`);
            var accountData = data.data[0];
            return (
                <Jumbotron>
                    <Wrapper>  
                        <Container>
                        
                            <h1>maskedccoundID: {accountData.maskedccoundID}</h1>
                            <Row>
                                <Col md={12}>
                                    {
                                        accountData["bankAccountVOLList"] === undefined ?
                                            "no bankAccountVOLList" 
                                        :
                                        accountData.bankAccountVOLList.map((item,index) => {
                                            return(
                                                <ul key={index}>
                                                    <li>accountType: {item.accountType}</li>
                                                    <li>bankAccountNumber: {item.bankAccountNumber}</li>
                                                    <li>bankAddress: </li>
                                                    <ul>
                                                        <li>addressLine1: {item.bankAddress.addressLine1}</li>
                                                        <li>addressLine2: {item.bankAddress.addressLine2}</li>
                                                        <li>city: {item.bankAddress.city}</li>
                                                        <li>state: {item.bankAddress.state}</li>
                                                        <li>zipCode: {item.bankAddress.zipCode}</li>
                                                        <li>zipCodeLast4: {item.bankAddress.zipCodeLast4}</li>
                                                    </ul>
                                                    <li>bankName: {item.bankName}</li>
                                                    <li>bankRoutingNumber: {item.bankRoutingNumber}</li>
                                                </ul>
                                            )
                                            
                                        })
                                    }
                                </Col>
                            </Row>  
                        </Container>
                    </Wrapper>
                </Jumbotron>
            )
        }
    }
}

const Wrapper = styled.div`

`;
